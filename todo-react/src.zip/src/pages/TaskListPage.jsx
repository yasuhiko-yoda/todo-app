import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "../components/common/Button";
import { createTask, deleteTask, fetchTasks, updateTask } from "../api/taskApi";
import "./common.css";

export const TaskListPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState(() => location.state?.message ?? "");
  const [accessDenied, setAccessDenied] = useState(false);
  const [taskContent, setTaskContent] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const updateForm = (event) => {
    setTaskContent(event.target.value);
  };

  const loadTasks = async () => {
    // fetchTasks内でJSONへ変換している場合
    const data = await fetchTasks();
    setTasks(data);
  };

  useEffect(() => {
    // メッセージを取り込んだ後、履歴に残ったstateを削除
    if (location.state?.message) {
      navigate(location.pathname, {
        replace: true,
        state: null,
      });
    }
  }, [location.pathname, location.state?.message, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        await loadTasks();
      } catch (error) {
        console.error(error);

        if (error.status === 401 || error.status === 403) {
          setAccessDenied(true);
        } else {
          setMessage("タスク一覧の取得に失敗しました。");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleComplete = async (task) => {
    setMessage("");

    try {
      await updateTask(task.taskId, {
        taskContent: task.taskContent,
        completed: !task.completed,
      });

      await loadTasks();
      // setMessage("タスクを完了しました。");
    } catch (error) {
      console.error(error);
      setMessage("タスクの完了処理に失敗しました。");
    }
  };

  const handleDelete = async (taskId) => {
    // console.log("削除するタスクID", taskId);
    setMessage("");
    try {
      await deleteTask(taskId);
      await loadTasks();
    } catch (error) {
      console.error(error);
      setMessage("タスクの削除に失敗しました。");
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setMessage("");
    if (!taskContent.trim()) {
      setMessage("タスク内容を入力してください。");
      return;
    }
    try {
      setSubmitting(true);
      await createTask({
        taskContent: taskContent.trim(),
        completed: false,
      });

      setTaskContent("");
      await loadTasks();

      setMessage("タスクを登録しました。");
    } catch (error) {
      console.error(error);
      if (error.status === 400) {
        setMessage(error.message || "入力内容を確認してください。");
      } else if (error.status === 401) {
        setMessage("ログインが必要です。");
      } else if (error.status === 403) {
        setMessage("この操作を行う権限がありません。");
      } else {
        setMessage(error.message);
      }
    } finally {
      setSubmitting(false)
    }
  };

  if (loading) {
    return <p>タスクを読み込んでいます。</p>;
  }

  if (accessDenied) {
    return <p>タスクを取得する権限がありません。</p>;
  }

  return (
    <div>
      <h2>タスク一覧</h2>

      {message && <p>{message}</p>}

      {tasks.length === 0 ? (
        <p>登録されているタスクはありません。</p>
      ) : (
        <ul className="task-list">
          {tasks.map((task) => (
            <li key={task.taskId}>
              <span className={task.completed ? "completed" : ""}>
                {task.taskContent}
              </span>

              <div>
                <Link to={`/tasks/${task.taskId}`}>編集</Link>

                <Button
                  btnColor="white"
                  btnBgColor={task.completed ? "gray" : "red"}
                  type="button"
                  size="medium"
                  btnName={task.completed ? "未完了に戻す" : "完了"}
                  onClick={() => handleComplete(task)}
                />

                <Button
                  btnColor="white"
                  btnBgColor="red"
                  type="button"
                  size="medium"
                  btnName="削除"
                  onClick={() => handleDelete(task.taskId)}
                />
              </div>
            </li>
          ))}
        </ul>
      )}

      <h2>タスク登録</h2>

      <form onSubmit={handleSubmit}>
        <label htmlFor="taskContent">タスク内容</label>
        <input
          id="taskContent"
          name="taskContent"
          type="text"
          value={taskContent}
          onChange={updateForm}
          placeholder="タスクを登録してください"
        />

        <Button
          btnColor="white"
          btnBgColor="red"
          tnName={submitting ? "登録中..." : "登録する"}
          disabled={submitting}
          size="medium"
          btnName="登録する"
        />
      </form>
    </div>
  );
};
