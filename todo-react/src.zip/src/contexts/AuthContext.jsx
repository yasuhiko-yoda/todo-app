import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState({
    isAuthenticated: false,
    username: null,
    isAdmin: false,
    loading: true,
  });

  const checkAuthStatus = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/auth/status", {
        method: "GET",
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("認証状態を取得できませんでした。");
      }

      const data = await response.json();

      setAuth({
        isAuthenticated: data.authenticated,
        username: data.username ?? null,
        isAdmin: data.isAdmin ?? false,
        loading: false,
      });

      return data;
    } catch (error) {
      console.error(error);

      setAuth({
        isAuthenticated: false,
        username: null,
        isAdmin: false,
        loading: false,
      });

      return null;
    }
  };

  useEffect(() => {
    checkAuthStatus();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        ...auth,
        checkAuthStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
