export const Button = ({
  btnColor,
  btnBgColor,
  type,
  size,
  btnName,
  onClick,
}) => {
  return (
    <button
      type={type}
      className={size}
      style={{
        color: btnColor,
        backgroundColor: btnBgColor,
      }}
      onClick={onClick}
    >
      {btnName}
    </button>
  );
};
